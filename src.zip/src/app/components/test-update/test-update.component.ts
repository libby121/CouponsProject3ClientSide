import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-update',
  templateUrl: './test-update.component.html',
  styleUrls: ['./test-update.component.css']
})
export class TestUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
