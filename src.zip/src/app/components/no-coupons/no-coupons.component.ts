import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-coupons',
  templateUrl: './no-coupons.component.html',
  styleUrls: ['./no-coupons.component.css']
})
export class NoCouponsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
