export enum ClientType {
    Administrator,Company, Customer

}
